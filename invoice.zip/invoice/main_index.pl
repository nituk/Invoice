#!/usr/bin/perl

use strict;
use warnings;
use Switch;

$\ = "\n";
my $client_file = "abcd";
my $company_file = "abcd";
my $sample = "sample.html";

open(FILE, 'INVOICE.txt') || die "Can't open file: $!";
my $invoice_no = <FILE>;
close FILE;

chomp $invoice_no;
$invoice_no++;

my ($sec,$min,$hr,$mday,$mon,$year,$wday,$yday,$isdst) = localtime(time);
$year += 1900;
my @abbr = qw( Jan Feb Mar Apr May June July Aug Sep Oct Nov Dec );
my $current_date = $abbr[$mon]." ".$mday.", ".$year;

my $client_name;
my $INVOICE_FILE;
my $company_name ;
my $rate_per_day ;
my $training_days ;
my $dates ;
my $technology ;
my $city ;
my $reply = 'y' ;
my $amount;
my $total_amount;
my $description;

sub ask {
	my $var = shift;
	print "Enter $var:";
	my $input = <STDIN>;
	chomp $input;
	return $input;
}

sub ask_file {
	my $file_name = shift;
	my $var = shift;
	open(FILE, $file_name) || return 0;
	my %line;
	$line{0} = 0;
	print "Existing $var Names:";
	while (<FILE>){
		chomp;
		$line{$.} = $_;
		print "$.:$_";
	}
	close FILE;
	print "Enter 0 to enter value manually:";
	my $value = <STDIN>;
	chomp $value;
	return $line{$value};

}
sub default_value {
	$company_name = ask_file($company_file,"Company") || ask("Company Name");
	$rate_per_day = 1000;
	$training_days = 1;
	$dates = '29/01/2013';
	$technology = 'Unix Shell Scripting';
	$city = 'Pune';
}


sub write_html {
	my $input = shift;
	my $output = shift;
	my $mode = shift;
	open my $in, '<', $input or die "Can't read sample HTML file: $!";
	open my $out, $mode, $output or die "Can't write HTML file: $!";
	while ( <$in> ) {
		chomp;
		s/<invoice_no>/$invoice_no/ ; 
		s/<current_date>/$current_date/ ;
		s/<client_name>/$client_name/ ;
		s/<description>/$description/;
		s/<amount>/$amount/ ;
		s/<total_amount>/$total_amount/ ;
		print $out $_;
	}
	close $in;
	close $out;
}

sub training_details {
	$company_name = ask_file($company_file,"Company") || ask("Company Name");
	$rate_per_day = ask("rate per day");
	$training_days = ask("No. of training days");
	$dates = ask("Dates on which training was conducted");
	$technology = ask("Technology");
	$city = ask("City in which training was conducted:");
}

$client_name = ask_file($client_file,"Client") || ask("Client Name");

$INVOICE_FILE = $client_name."_".$invoice_no.".html";

write_html('index1.html', $INVOICE_FILE, '>');

while ($reply =~ /^[yY]/ ) {
	#training_details();
	default_value();
	while (1) {
		system("clear");
		print "The Entered values are:";
		print "1.Client Name==> $client_name";
		print "2.Company Name==> $company_name";
		print "3.Rate per day==> $rate_per_day";
		print "4.Training conducted in days==> $training_days";
		print "5.Training dates==> $dates";
		print "6.Technology==> $technology";
		print "7.City==> $city";
		print "Enter 0 to continue";
		my $reply = <STDIN>;
		chomp $reply;
		last if ( $reply == 0 ) ;
		switch ($reply) {
			case 1	{ $client_name = ask_file($client_file, "Client") || ask("Client Name") }
			case 2	{ $company_name = ask_file($company_file, "Company") || ask("Company Name") }
			case 3	{ $rate_per_day = ask("rate per day") }
			case 4	{ $training_days = ask("No. of training days") }
			case 5	{ $dates = ask("Dates on which training was conducted") }
			case 6	{ $technology = ask("Technology") }
			case 7	{ $city = ask("City in which training was conducted:") }
		}
	}
	$amount = $rate_per_day * $training_days;
	$total_amount += $amount;
	$description = $technology." ".$company_name." ".$city." ".$dates;
	write_html('index2.html', $INVOICE_FILE, '>>');
	print "Do you want to add more products?";
	$reply = <STDIN>;
	chomp $reply;

}
write_html('index3.html', $INVOICE_FILE, '>>');


print "Invoice Name: $INVOICE_FILE";

open my $FILE, '>', 'INVOICE.txt';
print $FILE $invoice_no;
close $FILE;
